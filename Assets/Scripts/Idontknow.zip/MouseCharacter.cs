﻿using UnityEngine;
using System.Collections;
using System;

public class MouseCharacter : MonoBehaviour
{
    Animator mouseAnimator;
   /* public bool jumpStart = false;
    public float groundCheckDistance = 0.1f;
    public float groundCheckOffset = 0.01f;
    public bool isGrounded = true;
    public float jumpSpeed = 2f;*/
    Rigidbody mouseRigid;
    private bool isPressed;
    // 0 = Stand, 1 = Run , 2 = Sneak, 3 = Crawl
    public int playerState = 0;
    public GameState gameState;

    // Speed for animation
    public float forwardSpeed;
    public float turnSpeed;
    public float walkMode = 1f;
    public float speed = 1f;
    public float runSpeed = 2f;
    public float sneakSpeed = 0.5f;
    public float crawlSpeed = 0.1f;
    private float tempSpeed;


    void Start()
    {
        mouseAnimator = GetComponent<Animator>();
        mouseRigid = GetComponent<Rigidbody>();
        tempSpeed = speed;
    }

    void Update()
    {
        // Movement
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        Vector3 movement = new Vector3(horizontal, 0, vertical);
        movement *= 2* speed * Time.deltaTime;

   /*     // Animating
        float Forward = Vector3.Dot(movement.normalized, transform.forward);
        float Turn = Vector3.Dot(movement.normalized, transform.right);
*/
        mouseAnimator.SetFloat("Forward", vertical, 0.1f, Time.deltaTime);
        mouseAnimator.SetFloat("Turn", horizontal, 0.1f, Time.deltaTime);

        

        // Run
        if (Input.GetKeyDown(KeyCode.Space))
        {
            isPressed = !isPressed;
            if (isPressed)
            {
                playerState = 1;
                Debug.Log("state1 speed: " + speed);
            }
        }
        if (Input.GetKeyUp(KeyCode.Space))
        {
            isPressed = false;
            Debug.Log(movement);
        }
        // Sneak
        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            isPressed = !isPressed;
            if (isPressed)
            {
                playerState = 2;
                Debug.Log("state2 speed: " + speed);
            }
        }
        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            isPressed = false;
        }
        // Crawl
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            isPressed = !isPressed;
            if (isPressed)
            {
                playerState = 3;
                Debug.Log("state3 speed: " + speed);
            }
        }
        if (Input.GetKeyUp(KeyCode.LeftControl))
        {
            isPressed = false;
        }
        if (!isPressed)
        {
            playerState = 0;
            Debug.Log("state0 speed: " + speed);
        }
        gameState.playerState = playerState;
        /* if (movement.magnitude > 0)
         {
             movement.Normalize();
             movement *= speed * Time.deltaTime;
         }*/
        
        
    }
    void FixedUpdate()
    {
        if (playerState == 0 && speed != 0.0f)
        {
            speed = tempSpeed;
            mouseAnimator.SetFloat("Forward", Math.Abs(speed));
            Debug.Log("state0 speed: " + speed);
        }
        if (playerState == 1)
        {
            mouseAnimator.SetFloat("Forward", runSpeed);
            speed = runSpeed;
        }
        if (playerState == 2)
        {
            mouseAnimator.SetFloat("Forward", sneakSpeed);
            speed = sneakSpeed;

        }
        if (playerState == 3)
        {
            mouseAnimator.SetFloat("Forward", crawlSpeed);
            speed = crawlSpeed;
        }
        else
        {
            mouseAnimator.SetFloat("Forward", 0.0f);
            mouseAnimator.SetFloat("Turn", 0.0f);
        }
        
    }

}
