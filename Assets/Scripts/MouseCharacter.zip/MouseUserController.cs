﻿using UnityEngine;
using System.Collections;

public class MouseUserController : MonoBehaviour
{
    MouseCharacter mouseCharacter;

    void Start()
    {
        mouseCharacter = GetComponent<MouseCharacter>();
    }

    void Update()
    {
  
        if (Input.GetKeyDown(KeyCode.Space))
        {
            mouseCharacter.Run();
        }

        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            mouseCharacter.Sneak();
        }

        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            mouseCharacter.Crawl();
        }

        mouseCharacter.forwardSpeed = mouseCharacter.maxWalkSpeed * Input.GetAxis("Vertical");
        mouseCharacter.turnSpeed = Input.GetAxis("Horizontal");
    }

}
