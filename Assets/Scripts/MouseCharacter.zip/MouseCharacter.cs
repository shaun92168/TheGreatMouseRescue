﻿using UnityEngine;
using System.Collections;

public class MouseCharacter : MonoBehaviour
{
    Animator mouseAnimator;
    public bool jumpStart = false;
    public float groundCheckDistance = 0.1f;
    public float groundCheckOffset = 0.01f;
    public bool isGrounded = true;
    public float jumpSpeed = 2f;
    Rigidbody mouseRigid;
    public float forwardSpeed;
    public float turnSpeed;
    public float walkMode = 1f;
    public float jumpStartTime = 0f;
    public float maxWalkSpeed = 1f;

    void Start()
    {
        mouseAnimator = GetComponent<Animator>();
        mouseRigid = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        //CheckGroundStatus();
        Move();
        jumpStartTime += Time.deltaTime;
        maxWalkSpeed = Mathf.Lerp(maxWalkSpeed, walkMode, Time.deltaTime);
    }

    public void Run()
    {
        forwardSpeed = 1f;
    }

    public void Sneak()
    {
        forwardSpeed = .3f;
    }
    public void Crawl()
    {
        forwardSpeed = .1f;
    }

    public void Walk()
    {
        forwardSpeed = .5f;
    }

    public void Move()
    {
        mouseAnimator.SetFloat("Forward", forwardSpeed);
        mouseAnimator.SetFloat("Turn", turnSpeed);
    }
}
